// create a reducer function for the functionality
const UserReducer = (state, action) => {
  switch (action.type) {
    case "PATIENT_DATA":
      return {
        ...state,
        patient: action.payload.patient,
      };
    case "DONOR_DATA":
      return {
        ...state,
        donor: action.payload.donor,
      };

    default:
      return state;
  }
};

export default UserReducer;
