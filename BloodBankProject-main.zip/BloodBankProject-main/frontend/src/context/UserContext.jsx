import React, { createContext, useContext, useEffect, useReducer } from "react";
import reducer from "./reducer/UserReducer";
const UserContext = createContext();

const UserProvider = ({ children }) => {
  const initialState = {
    patient: [],
    donor: [],
  };

  const [state, dispatch] = useReducer(reducer, initialState);

  const getPatientData = (patient) => {
    dispatch({ type: "PATIENT_DATA", payload: { patient } });
  };
  const getDonorData = (donor) => {
    dispatch({ type: "DONOR_DATA", payload: { donor } });
  };

  useEffect(() => {
    getPatientData(), getDonorData();
  }, []);

  return (
    <UserContext.Provider value={{ ...state, getPatientData, getDonorData }}>
      {children}
    </UserContext.Provider>
  );
};

const useUserContext = () => {
  return useContext(UserContext);
};

export { useUserContext, UserProvider, UserContext };
