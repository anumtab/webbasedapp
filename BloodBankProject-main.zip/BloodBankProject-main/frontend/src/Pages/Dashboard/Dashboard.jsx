import React, { useEffect, useState } from "react";
import { useAuthContext } from "../../context/authContext";
import { useInventoryContext } from "../../context/InventoryContext";
import { useUserContext } from "../../context/UserContext";

const Dashboard = () => {
  const { data } = useAuthContext();
  const { email, name, gender, age } = data;
  const { loading, inventory } = useInventoryContext();
  const [bloodBankStock, setBloodBankStock] = useState([]);
  // const { donor, patient } = useUserContext();

  const bloodbankstock = () => {
    const bloodbankNames = inventory.map((item) => item.bloodbank);
    setBloodBankStock(bloodbankNames);
  };

  useEffect(() => {
    bloodbankstock();
  }, [inventory]);

  return (
    <>
      <div className="p-4 sm:ml-64">
        <div className="p-4 border-2 border-gray-200 border-dashed rounded-lg mt-14">
          <h1 className="text-[30px] my-6 font-bold capitalize">
            Welcome Back {name} 👏
          </h1>
          <div className="grid grid-cols-3 gap-4 mb-4">
            <article className="flex flex-col gap-4 rounded-lg border border-gray-100 bg-white p-6">
              <div className="inline-flex gap-2 self-end rounded bg-green-100 p-1 text-green-600">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                  />
                </svg>

                <span className="text-xs font-medium"> 67.81% </span>
              </div>

              <div>
                <strong className="block text-sm font-medium text-gray-500">
                  Total Donor
                </strong>

                <p>
                  <span className="text-2xl font-medium text-gray-900">14</span>
                </p>
              </div>
            </article>

            <article className="flex flex-col gap-4 rounded-lg border border-gray-100 bg-white p-6">
              <div className="inline-flex gap-2 self-end rounded bg-red-100 p-1 text-red-600">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"
                  />
                </svg>
              </div>

              <div>
                <strong className="block text-sm font-medium text-gray-500">
                  Total Patient
                </strong>

                <p>
                  <span className="text-2xl font-medium text-gray-900">12</span>
                </p>
              </div>
            </article>

            <article className="flex flex-col gap-4 rounded-lg border border-gray-100 bg-white p-6">
              <div className="inline-flex gap-2 self-end rounded bg-red-100 p-1 text-red-600">
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-4 w-4"
                  fill="none"
                  viewBox="0 0 24 24"
                  stroke="currentColor"
                >
                  <path
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    strokeWidth="2"
                    d="M13 17h8m0 0V9m0 8l-8-8-4 4-6-6"
                  />
                </svg>

                <span className="text-xs font-medium"> 67.81% </span>
              </div>

              <div>
                <strong className="block text-sm font-medium text-gray-500">
                  Total Blood Bank
                </strong>

                <p>
                  <span className="text-2xl font-medium text-gray-900">
                    {bloodBankStock.length}
                  </span>
                </p>
              </div>
            </article>
          </div>
        </div>
      </div>
    </>
  );
};

export default Dashboard;
