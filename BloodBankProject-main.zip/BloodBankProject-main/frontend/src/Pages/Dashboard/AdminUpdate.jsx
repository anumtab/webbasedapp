import { useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import { FaRegEye } from "react-icons/fa";
import { FaRegEyeSlash } from "react-icons/fa";
import HashLoader from "react-spinners/HashLoader";
import { toast } from "react-toastify";
import { useAuthContext } from "../../context/authContext";
import { BASE_URL, token } from "../../../config.js";

const AdminUpdate = () => {
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const { data } = useAuthContext();
  const [RegisterformData, setRegisterformData] = useState({
    name: "",
    email: "",
    password: "",
    confirmpassword: "",
    phone: "",
    age: "",
    gender: "",
    bloodGroup: "",
    lastDonationDate: "",
  });

  const params = useParams();

  const getSingleDonerData = async () => {
    try {
      const res = await fetch(`${BASE_URL}/admin/doner/${params.id}`, {
        headers: { Authorization: `Bearer ${token}` },
        method: "GET",
      });
      const result = await res.json();
      if (!res.ok) {
        throw new Error(result.message + "🤢");
      }
      setRegisterformData(result.data);
    } catch (error) {
      toast.error(error);
    }
  };

  useEffect(() => {
    getSingleDonerData();
  }, []);

  const HandleLoginInput = (e) => {
    e.preventDefault();
    setRegisterformData({
      ...RegisterformData,
      [e.target.name]: e.target.value,
    });
  };

  const togglePasswordVisibility = () => {
    setShowPassword(!showPassword);
  };

  const HandleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(`${BASE_URL}/admin/doner/update/${params.id}`, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        method: "put",
        body: JSON.stringify(RegisterformData),
      });
      const result = await res.json();
      toast.success(result.message);
      // toast.success(result.error);
      setRegisterformData(result);
      setLoading(false);
    } catch (error) {
      console.log(error);
      toast.error(error);
    }
  };

  return (
    <div>
      <div className="p-4 sm:ml-64">
        <div className="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700 mt-14">
          <div class="grid grid-col-2 grid-flow-col gap-4">
            <section className="py-5 lg:px-0">
              <div className="w-full  mx-auto rounded-lg shadow-md md:p-10 p-10 ">
                <h3 className="text-headingColor text-[22px] font-bold leading-9 mb-6">
                  Update Your
                  <span className="text-backgroundColor">
                    Account Credentials
                  </span>
                  🎉
                </h3>
                <form className="py-4 md:py-0" onSubmit={HandleSubmit}>
                  <div className=" grid grid-cols-2 gap-4 lg:grid-cols-2">
                    <div className="my-3">
                      <input
                        type="text"
                        placeholder="Enter Your Full Name"
                        name="name"
                        required
                        value={RegisterformData.name}
                        onChange={HandleLoginInput}
                        className="w-full px-4 py-3 border-b border-solid border-backgroundColor
           focus:outline-none focus:border-b-backgroundColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
                      />
                    </div>
                    <div className="my-3">
                      <input
                        type="email"
                        required
                        placeholder="Enter Your Email"
                        name="email"
                        value={RegisterformData.email}
                        onChange={HandleLoginInput}
                        className="w-full px-4 py-3 border-b border-solid border-primaryColor
           focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-primaryColor"
                      />
                    </div>
                    <div className="my-3 flex relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        placeholder="Enter Your Password"
                        name="password"
                        value={RegisterformData.value}
                        onChange={HandleLoginInput}
                        className="w-full px-4 py-3 border-b border-solid border-primaryColor
           focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
                      />
                      <div
                        className="absolute flex justify-end bottom-[20px] left-[88%] w-10 overflow-hidden"
                        onClick={togglePasswordVisibility}
                      >
                        {!showPassword ? <FaRegEyeSlash /> : <FaRegEye />}
                      </div>
                    </div>

                    <div className="my-3 flex relative">
                      <input
                        type={showPassword ? "text" : "password"}
                        placeholder="Enter Your Confirm Password"
                        name="confirmpassword"
                        value={RegisterformData.confirmpassword}
                        onChange={HandleLoginInput}
                        className="w-full px-4 py-3 border-b border-solid border-primaryColor
           focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
                      />
                      <div
                        className="absolute flex justify-end bottom-[20px] left-[88%] w-10 overflow-hidden"
                        onClick={togglePasswordVisibility}
                      >
                        {!showPassword ? <FaRegEyeSlash /> : <FaRegEye />}
                      </div>
                    </div>

                    <div className="my-3">
                      <input
                        type="number"
                        placeholder="Enter Your Age"
                        name="age"
                        value={RegisterformData.age}
                        onChange={HandleLoginInput}
                        className="w-full px-4 py-3 border-b border-solid border-b-primaryColor
            focus:border-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
                      />
                    </div>

                    <div className="my-3">
                      <input
                        type="number"
                        placeholder="Enter Your Phone Number"
                        name="phone"
                        value={RegisterformData.phone}
                        onChange={HandleLoginInput}
                        className="w-full px-4 py-3 border-b border-solid border-primaryColor
           focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
           placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
                      />
                    </div>
                    {data.role == "doner" && (
                      <div className="my-5">
                        <input
                          type="date"
                          placeholder="Enter Last Donation Date"
                          name="lastDonationDate"
                          value={RegisterformData.lastDonationDate}
                          onChange={HandleLoginInput}
                          className="w-full px-4 py-3 border-b border-solid border-primaryColor
         focus:outline-none focus:border-b-primaryColor leading-7 text-headingColor text-[19px]
         placeholder:text-greyColor rounded-md cursor-pointer focus:ring-backgroundColor"
                        />
                      </div>
                    )}

                    <div className="mb-5 flex justify-between items-center">
                      <label className="text-headingColor font-bold text-[16px] leading-7">
                        Gender:
                        <select
                          onChange={HandleLoginInput}
                          value={RegisterformData.gender}
                          name="gender"
                          className="text-greyColor font-semibold 
                text-[15px] leading-7 focus:outline-none py-1 outline-none focus:ring-backgroundColor"
                        >
                          <option value="">Select</option>
                          <option value="male">Male</option>
                          <option value="female">Female</option>
                          <option value="other">Other</option>
                        </select>
                      </label>

                      <label className="text-headingColor font-bold text-[16px] leading-7">
                        Blood Group:
                        <select
                          onChange={HandleLoginInput}
                          value={RegisterformData.bloodGroup}
                          name="bloodGroup"
                          className="text-greyColor font-semibold 
                text-[15px] leading-7 outline-none focus:outline-none py-1 focus:ring-backgroundColor"
                        >
                          <option value="">Select</option>
                          <option value="A+">A+</option>
                          <option value="B+">B+</option>
                          <option value="O+">O+</option>
                          <option value="A-">A-</option>
                          <option value="B-">B-</option>
                          <option value="O-">O-</option>
                          <option value="AB+">AB+</option>
                          <option value="AB-">AB-</option>
                        </select>
                      </label>
                    </div>
                  </div>
                  <div>
                    <button
                      disabled={loading && true}
                      type="submit"
                      className="btn w-full rounded-md text-[16px] hover:shadow-lg"
                    >
                      Update
                    </button>
                  </div>
                </form>
              </div>
            </section>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminUpdate;
