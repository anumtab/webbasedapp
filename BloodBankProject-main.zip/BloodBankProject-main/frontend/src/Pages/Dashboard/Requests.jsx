import React, { useState, useEffect } from "react";
import { BASE_URL } from "../../../config";
import { useAuthContext } from "../../context/authContext";

const Requests = () => {
  const { data } = useAuthContext();

  const [appointment, setAppointments] = useState([]);
  const [donorName, setDonorName] = useState();
  // console.log(appointment.donorId);
  useEffect(() => {
    const fetchAppointments = async () => {
      try {
        const res = await fetch(`${BASE_URL}/patient/${data._id}/appointments`);
        const result = await res.json();
        const my_appointments = result.data.appointments;
        setAppointments(my_appointments);
        // console.log(my_appointments);
      } catch (err) {
        console.error(err);
      }
    };
    fetchAppointments();
  }, []);

  const donorNames = appointment.map((appointment) => appointment.donorId);
  // setDonorName(donorNames);
  console.log(donorNames);

  const getStatusClass = (status) => {
    switch (status) {
      case "pending":
        return "bg-yellow-100 text-yellow-800";
      case "accepted":
        return "bg-green-100 text-green-800";
      case "rejected":
        return "bg-red-100 text-red-800";
      default:
        return "";
    }
  };

  return (
    <div className="p-4 sm:ml-64">
      <div className="p-4 border-2 border-gray-200 border-dashed rounded-lg mt-14">
        <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
          <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
              <tr>
                <th scope="col" class="px-6 py-3">
                  S.No
                </th>
                <th scope="col" class="px-6 py-3">
                  <div class="flex items-center">Donor Name</div>
                </th>
                <th scope="col" class="px-6 py-3">
                  <div class="flex items-center">Age</div>
                </th>
                <th scope="col" class="px-6 py-3">
                  <div class="flex items-center">Blood Group</div>
                </th>
                <th scope="col" class="px-6 py-3">
                  <div class="flex items-center">Phone</div>
                </th>

                <th scope="col" class="px-6 py-3">
                  <div class="flex items-center">Status</div>
                </th>
              </tr>
            </thead>
            {appointment.length > 0 ? (
              <>
                {appointment?.map((elem, index) => {
                  return (
                    <tbody>
                      <tr class="bg-white border-b dark:bg-gray-800 dark:border-gray-700">
                        <th
                          scope="row"
                          class="px-6 py-4 capitalize font-medium text-gray-900 whitespace-nowrap dark:text-white"
                        >
                          {index + 1}
                        </th>
                        <th
                          scope="row"
                          class="px-6 py-4 capitalize font-medium text-gray-900 whitespace-nowrap dark:text-white"
                        >
                          {elem.donorId.name}
                        </th>
                        <td class="px-6 py-4"> {elem.donorId.age}</td>
                        <td class="px-6 py-4"> {elem.donorId.bloodGroup}</td>
                        <td class="px-6 py-4">{elem.donorId.phone}</td>
                        <td class="px-6 py-4">
                          <p>
                            <span
                              className={`text-xs font-medium me-2 px-2.5 py-0.5 rounded ${getStatusClass(
                                elem.status
                              )}`}
                            >
                              {elem.status}
                            </span>
                          </p>
                        </td>
                      </tr>
                    </tbody>
                  );
                })}
              </>
            ) : (
              <h1 className="text-[25px] my-6 font-bold capitalize p-5">
                No Request Added
              </h1>
            )}
          </table>
        </div>
      </div>
    </div>
  );
};

export default Requests;
