import React from "react";
import { BASE_URL } from "../../../config.js";
import useFetchData from "../../hook/useFetchData.jsx";
import { Loading } from "../../utils/LoadingTable.jsx";
import PatientCard from "./PatientCard.jsx";
const PatientCardList = () => {
  const { loading, data, error } = useFetchData(`${BASE_URL}/patient/`);
  return (
    <div>
      <div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {loading && <Loading />}
          {!loading &&
            !error &&
            data.map((curElem, index) => {
              return <PatientCard key={index} data={curElem} />;
            })}
        </div>
      </div>
    </div>
  );
};

export default PatientCardList;
