import React from "react";
import InventoryUpdateModal from "./InventoryUpdateModal";

const InventoryTable = ({ data }) => {
  return (
    <>
      {data.map((elem, index) => {
        return (
          <div
            key={index}
            class="relative overflow-x-auto shadow-md sm:rounded-lg my-5"
          >
            <div className="grid grid-cols-2 gap-4 lg:grid-cols-2">
              <div className="p-5 text-lg font-bold text-left rtl:text-left text-backgroundColor bg-white">
                {elem.bloodbank}
              </div>
              <div className="p-5 text-lg font-bold text-right rtl:text-right text-backgroundColor bg-white">
                <InventoryUpdateModal inventoryId={elem._id} />
              </div>
            </div>
            <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
              <thead class="text-xs text-gray-700 uppercase bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                  <th scope="col" class="px-6 py-3">
                    S.No
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Blood Groups
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Availablity
                  </th>
                  <th scope="col" class="px-6 py-3">
                    Last Update
                  </th>
                </tr>
              </thead>
              <tbody>
                {elem.blood.map((blood, index) => {
                  return (
                    <tr
                      key={index}
                      class="bg-white border-b dark:bg-gray-800 dark:border-gray-700"
                    >
                      <th
                        scope="row"
                        class="px-6 py-4 font-medium text-gray-900 whitespace-nowrap dark:text-white"
                      >
                        {index + 1}
                      </th>
                      <td class="px-6 py-4">{blood.bloodGroup}</td>
                      <td class="px-6 py-4">{blood.available}</td>
                      <td class="px-6 py-4">{elem.updatedAt}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        );
      })}
    </>
  );
};

export default InventoryTable;
