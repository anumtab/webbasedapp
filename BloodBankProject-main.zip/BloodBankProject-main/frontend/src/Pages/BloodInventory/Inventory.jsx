import React, { useEffect, useState } from "react";
import { toast } from "react-toastify";
import { BASE_URL } from "../../../config";
import InventoryTable from "./InventoryTable";
import LoadingTable from "../../utils/LoadingTable";
import InventoryModal from "./InventoryModal";
import { useAuthContext } from "../../context/authContext";
import { useInventoryContext } from "../../context/InventoryContext";

const Inventory = () => {
  // const [inventory, setInventory] = useState(false);
  // const [loading, setLoading] = useState(false);
  const { role } = useAuthContext();
  const { loading, inventory, getInventoryData } = useInventoryContext();

  // const fetchData = async () => {
  //   setLoading(true);
  //   try {
  //     const res = await fetch(`${BASE_URL}/inventory/`);
  //     const result = await res.json();
  //     if (!res.ok) {
  //       throw new Error(result.message);
  //     }
  //     setInventory(!inventory);
  //     setLoading(false);
  //     getInventoryData(result.data);
  //   } catch (error) {
  //     setLoading(false);
  //     toast.error(error.message);
  //   }
  // };

  // useEffect(() => {
  //   fetchData();
  // }, []);

  return (
    <>
      <div className="p-4 sm:ml-64">
        <div className="p-4 border-2 border-gray-200 border-dashed rounded-lg mt-14">
          {role === "admin" ? <InventoryModal /> : null}

          <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
            {loading ? <LoadingTable /> : <InventoryTable data={inventory} />}
          </div>
        </div>
      </div>
    </>
  );
};

export default Inventory;
