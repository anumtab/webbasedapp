import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { Modal } from "flowbite-react";
import { BASE_URL, token } from "../../../config";
import { toast } from "react-toastify";
import { CiSquarePlus } from "react-icons/ci";
import { MdOutlineDeleteSweep } from "react-icons/md";
import { MdOutlineModeEdit } from "react-icons/md";
import { useAuthContext } from "../../context/authContext";
import { useInventoryContext } from "../../context/InventoryContext";

const InventoryUpdateModal = ({ inventoryId }) => {
  const [bloodbank, setBloodbank] = useState("");
  const [blood, setBlood] = useState([
    { bloodGroup: "", quantity: 0, available: "available" },
  ]);
  const [loading, setLoading] = useState(false);
  const [openModal, setOpenModal] = useState(false);
  const { role } = useAuthContext();
  const { getInventoryData } = useInventoryContext();
  function onCloseModal(e) {
    e.preventDefault();
    setOpenModal(false);
  }

  useEffect(() => {
    const fetchData = async (inventoryId) => {
      try {
        const res = await fetch(`${BASE_URL}/admin/inventory/${inventoryId}`, {
          headers: { Authorization: `Bearer ${token}` },
        });
        const result = await res.json();
        if (!res.ok) {
          throw new Error(result.message);
        }

        setBloodbank(result.data.bloodbank);
        setBlood(result.data.blood);
      } catch (error) {
        setLoading(false);
        toast.error(error.message);
      }
    };
    fetchData(inventoryId);
  }, [inventoryId]);

  const handleBloodChange = (index, event) => {
    const newBlood = blood.slice();
    newBlood[index][event.target.name] = event.target.value;
    setBlood(newBlood);
  };

  const handleAddBlood = () => {
    setBlood([
      ...blood,
      { bloodGroup: "", quantity: 0, available: "available" },
    ]);
  };

  const handleRemoveBlood = (index) => {
    const newBlood = blood.slice();
    newBlood.splice(index, 1);
    setBlood(newBlood);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await fetch(
        `${BASE_URL}/admin/inventory/update/${inventoryId}`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
          method: "PUT",
          body: JSON.stringify({ blood, bloodbank }),
        }
      );
      const result = await res.json();
      toast.success(result.message);
      getInventoryData(result.data);
      setBloodbank(result.data.bloodbank);
      setBlood(result.data.blood);
      setLoading(false);
    } catch (error) {
      toast.error(error);
    }
  };

  const DeleteInventoryRecord = async () => {
    try {
      const res = await fetch(
        `${BASE_URL}/admin/inventory/delete/${inventoryId}`,
        {
          headers: { Authorization: `Bearer ${token}` },
          method: "delete",
        }
      );
      const result = await res.json();
      if (!res.ok) {
        throw new Error(result.message);
      }
      getInventoryData();
      toast.success(result.message);
    } catch (error) {
      setLoading(false);
      toast.error(error.message);
    }
  };

  return (
    <>
      {role === "admin" ? (
        <>
          <Link
            type="button"
            class=" inline-block rounded bg-backgroundColor px-5 py-3 mr-2 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
            onClick={() => setOpenModal(true)}
          >
            <MdOutlineModeEdit />
          </Link>
          <Link
            type="button"
            class=" inline-block rounded bg-backgroundColor px-5 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
            onClick={() => DeleteInventoryRecord()}
          >
            <MdOutlineDeleteSweep />
          </Link>
        </>
      ) : null}

      <Modal show={openModal} size="lg" onClose={onCloseModal} popup>
        <Modal.Header />
        <Modal.Body>
          <div className="space-y-8">
            <h3 className="text-xl font-medium text-gray-900 dark:text-white">
              Add New Inventory Record
            </h3>
            <form onSubmit={handleSubmit}>
              <div className="mt-4">
                <label>
                  Blood Bank:
                  <input
                    type="text"
                    value={bloodbank}
                    onChange={(e) => setBloodbank(e.target.value)}
                    className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5"
                    required
                  />
                </label>
              </div>
              {blood.map((bloodItem, index) => (
                <div key={index} className="flex flex-col gap-4 mt-4">
                  <label>
                    Blood Group:
                    <select
                      type="text"
                      name="bloodGroup"
                      value={bloodItem.bloodGroup}
                      onChange={(e) => handleBloodChange(index, e)}
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5"
                    >
                      <option value="">Select</option>
                      <option value="A+">A+</option>
                      <option value="B+">B+</option>
                      <option value="O+">O+</option>
                      <option value="A-">A-</option>
                      <option value="B-">B-</option>
                      <option value="O-">O-</option>
                      <option value="AB+">AB+</option>
                      <option value="AB-">AB-</option>
                    </select>
                  </label>
                  <label>
                    Quantity:
                    <input
                      type="number"
                      name="quantity"
                      value={bloodItem.quantity}
                      onChange={(e) => handleBloodChange(index, e)}
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5"
                    />
                  </label>
                  <label>
                    Availability:
                    <select
                      name="available"
                      value={bloodItem.available}
                      onChange={(e) => handleBloodChange(index, e)}
                      className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-backgroundColor-500 focus:border-backgroundColor-500 block w-full p-2.5"
                    >
                      <option value="available">Available</option>
                      <option value="non-available">Non-available</option>
                    </select>
                  </label>
                  <button
                    type="button"
                    onClick={() => handleRemoveBlood(index)}
                    className="mt-8 inline-block rounded bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <div className="flex justify-between">
                <button
                  type="button"
                  onClick={handleAddBlood}
                  className="mt-8 inline-block rounded bg-backgroundColor px-12 py-3 text-[24px] font-medium text-white transition hover:bg-[#4d4d4d]"
                >
                  <CiSquarePlus />
                </button>
                <button
                  type="submit"
                  className="mt-8 inline-block rounded bg-backgroundColor px-12 py-3 text-sm font-medium text-white transition hover:bg-[#4d4d4d]"
                >
                  Submit
                </button>
              </div>
            </form>
          </div>
        </Modal.Body>
      </Modal>
      {/* <form onSubmit={handleSubmit}>
      <div>
        <label>
          Blood Bank:
          <input
            type="text"
            value={bloodbank}
            onChange={(e) => setBloodbank(e.target.value)}
            required
          />
        </label>
      </div>
      {blood.map((bloodItem, index) => (
        <div key={index}>
          <label>
            Blood Group:
            <input
              type="text"
              name="bloodGroup"
              value={bloodItem.bloodGroup}
              onChange={(event) => handleBloodChange(index, event)}
            />
          </label>
          <label>
            Quantity:
            <input
              type="number"
              name="quantity"
              value={bloodItem.quantity}
              onChange={(event) => handleBloodChange(index, event)}
            />
          </label>
          <label>
            Availability:
            <select
              name="available"
              value={bloodItem.available}
              onChange={(event) => handleBloodChange(index, event)}
            >
              <option value="available">Available</option>
              <option value="non-available">Non-available</option>
            </select>
          </label>
          <button type="button" onClick={() => handleRemoveBlood(index)}>
            Remove
          </button>
        </div>
      ))}
      <button type="button" onClick={handleAddBlood}>
        Add Blood Entry
      </button>
      <button type="submit">Submit</button>
    </form> */}
    </>
  );
};

export default InventoryUpdateModal;
