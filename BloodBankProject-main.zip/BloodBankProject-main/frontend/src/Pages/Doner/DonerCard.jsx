import React, { useState } from "react";
import blood from "../../assets/images/blood-drop.png";
import DateFormetor from "../../utils/DateFormetor";
import HideMiddleDigits from "../../utils/HideMiddleDigits";
import EmailSendModal from "../../utils/EmailSendModal";

const DonerCard = ({ donerData }) => {
  //  this data is come form donnerCardList as a prop
  const { _id, name, email, age, bloodGroup, phone, lastDonationDate } =
    donerData;

  return (
    <>
      <section class="relative block overflow-hidden rounded-lg border border-gray-100 p-4 sm:p-6 lg:p-8">
        <span class="absolute inset-x-0 bottom-0 h-2 bg-gradient-to-r from-red-300 via-red-500 to-red-600"></span>

        <div class="sm:flex sm:justify-between sm:gap-4">
          <div>
            <h3 class="text-[25px] font-bold text-gray-900">{bloodGroup}</h3>
            <div class="mt-2">
              <p class="text-sm font-medium text-gray-600">Name</p>
              <p class="text-[18px] font-800 text-gray-900 sm:text-xl">
                {name}
              </p>
            </div>
          </div>

          <div class="hidden sm:block sm:shrink-0">
            <img
              alt=""
              src={blood}
              class="size-16 rounded-lg object-cover shadow-sm"
            />
          </div>
        </div>

        <div class="mt-2">
          <p class="text-sm font-medium text-gray-600">Age</p>
          <p class="text-pretty text-sm text-gray-500">{age}</p>
        </div>

        <div class="mt-2">
          <p class="text-sm font-medium text-gray-600">Contact</p>
          <p class="text-pretty text-sm text-gray-500">
            <HideMiddleDigits contactNumber={phone} />
          </p>
        </div>

        <div class="mt-2">
          <p class="text-sm font-medium text-gray-600">Email</p>
          <p class="text-pretty text-sm text-gray-800 text-[16px]">
            <HideMiddleDigits contactNumber={email} />
          </p>
        </div>

        <dl class="mt-6 flex gap-4 sm:gap-6">
          <div class="flex flex-col-reverse">
            <dd class="text-xs text-gray-500">
              <DateFormetor dateStr={lastDonationDate} />
            </dd>
            <dt class="text-sm font-medium text-gray-600">
              Last Donation Date
            </dt>
          </div>
        </dl>

        <EmailSendModal donerDetails={donerData} />
      </section>
    </>
  );
};

export default DonerCard;
