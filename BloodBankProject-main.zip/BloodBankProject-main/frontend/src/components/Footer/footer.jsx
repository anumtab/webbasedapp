import React from "react";
import Logo from "../../assets/images/logo.png";

import {
  AiFillYoutube,
  AiFillGithub,
  AiOutlineInstagram,
} from "react-icons/ai";
import { Link } from "react-router-dom";

const Footer = () => {
  const socialLinks = [
    {
      path: "#",
      icon: <AiFillYoutube className="group-hover:text-white w-4 h-4" />,
    },
    {
      path: "#",
      icon: <AiFillGithub className="group-hover:text-white w-4 h-4" />,
    },
    {
      path: "#",
      icon: <AiOutlineInstagram className="group-hover:text-white w-4 h-4" />,
    },
  ];
  const quickLinks1 = [
    {
      path: "/home",
      display: "Home",
    },
    {
      path: "/doctors",
      display: "FindaDoctor",
    },
    {
      path: "/services",
      display: "Services",
    },
    {
      path: "/contact",
      display: "Contact",
    },
  ];
  const quickLinks2 = [
    {
      path: "/home",
      display: "Home",
    },
    {
      path: "/doctors",
      display: "FindaDoctor",
    },
    {
      path: "/services",
      display: "Services",
    },
    {
      path: "/contact",
      display: "Contact",
    },
  ];
  const quickLinks3 = [
    {
      path: "/home",
      display: "Home",
    },
    {
      path: "/doctors",
      display: "FindaDoctor",
    },
    {
      path: "/services",
      display: "Services",
    },
    {
      path: "/contact",
      display: "Contact",
    },
  ];

  const year = new Date().getFullYear();

  // return (
  //   <footer className=" pt-10 bg-[#111111]">
  //     <div className="container">
  //       <div className="flex justify-between flex-col md:flex-row flex-wrap gap-[30px] list-none p-6">
  //         <div>
  //           <Link
  //             to="/"
  //             className="flex items-center space-x-3 rtl:space-x-reverse"
  //           >
  //             <img src={Logo} className="w-10" alt="Logo" />
  //           </Link>
  //           <p className="text-[16px] text-white pt-[2rem] w-[295px]">
  //             Duis aute irure dolor in reprehenderit velit esse cillum dolore eu
  //             fugiat nulla pariatur. Excepteur sint occaecat
  //           </p>
  //           <div className="flex items-center gap-3 mt-4">
  //             {socialLinks.map((link, index) => (
  //               <Link
  //                 to={link.path}
  //                 key={index}
  //                 className=" w-9 h-9 border border-solid border-textColor text-textColor rounded-full
  //             flex items-center justify-center group hover:bg-primaryColor hover:border-none"
  //               >
  //                 {link.icon}
  //               </Link>
  //             ))}
  //           </div>
  //         </div>

  //         <div>
  //           <h2 className="list-none text-[20px] leading-[30px] font-[700] mb-6 text-textColor">
  //             Quick Links
  //           </h2>
  //           {quickLinks1.map((link, index) => {
  //             return (
  //               <li className="mb-4" key={index}>
  //                 <Link
  //                   to={link.path}
  //                   className="text-[16px] leading-7 font-[400] text-textColor"
  //                 >
  //                   {link.display}
  //                 </Link>
  //               </li>
  //             );
  //           })}
  //         </div>

  //         <div>
  //           <h2 className="text-[20px] leading-[30px] font-[700] mb-6 text-textColor">
  //             I want to
  //           </h2>
  //           {quickLinks2.map((link, index) => {
  //             return (
  //               <li className="mb-4" key={index}>
  //                 <Link
  //                   to={link.path}
  //                   className="text-[16px] leading-7 font-[400] text-textColor"
  //                 >
  //                   {link.display}
  //                 </Link>
  //               </li>
  //             );
  //           })}
  //         </div>

  //         <div>
  //           <h2 className="text-[20px] leading-[30px] font-[700] mb-6 text-textColor">
  //             Support
  //           </h2>
  //           {quickLinks3.map((link, index) => {
  //             return (
  //               <li className="mb-4" key={index}>
  //                 <Link
  //                   to={link.path}
  //                   className="text-[16px] leading-7 font-[400] text-textColor"
  //                 >
  //                   {link.display}
  //                 </Link>
  //               </li>
  //             );
  //           })}
  //         </div>
  //       </div>
  //     </div>
  //     <div className="bg-[#000] py-5">
  //       <p className="text-[16px] text-center leading-7 font-[400] text-white mt-4">
  //         Copyright {year} developed by Nabeel Ahmed all right reserved.
  //       </p>
  //     </div>
  //   </footer>
  // );
};

export default Footer;
