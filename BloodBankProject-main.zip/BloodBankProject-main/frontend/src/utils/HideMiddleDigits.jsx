import React from "react";

function HideMiddleDigits({ contactNumber }) {
  // Convert the input to a string to manipulate it
  const contactNumberString = contactNumber.toString();

  // Calculate the length of the contact number
  const length = contactNumberString.length;

  // Determine the start and end indices for hiding
  const hideStart = Math.floor(length / 3); // Start hiding after one-third of the length
  const hideEnd = length - Math.floor(length / 3); // End hiding one-third before the end

  // Replace the middle digits with asterisks
  const hiddenContactNumber =
    contactNumberString.slice(0, hideStart) +
    "*".repeat(hideEnd - hideStart) +
    contactNumberString.slice(hideEnd);

  return hiddenContactNumber;
}

export default HideMiddleDigits;
