import React from "react";

const DateFormetor = ({ dateStr }) => {
  if (!dateStr) {
    return <h1>No last Date Added</h1>;
  }
  const [day, month, year] = dateStr.split("-");
  let newDate = `${day}-${month}-${year}`;
  return newDate;
};

export default DateFormetor;
