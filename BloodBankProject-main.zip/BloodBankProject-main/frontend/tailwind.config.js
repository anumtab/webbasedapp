/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,ts,jsx,tsx}"],
  theme: {
    extend: {
      colors: {
        backgroundColor: "#ea062b",
        primaryColor: "#ea062b",
        greyColor: "#454545",
        textColor: "#fff",
      },
    },
  },
  plugins: [require("flowbite/plugin")],
};
