import express from "express";
import {
  AddAppointment,
  getAppointments,
} from "../controllers/AuthController/appointmentController.js";

const router = express.Router();

router.post("/", AddAppointment);
router.get("/", getAppointments);

export default router;
