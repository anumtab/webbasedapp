import Doner from "../../models/DonerSchema.js";
import Patient from "../../models/PatientSchema.js";
import Appointment from "../../models/AppointmentSchema.js";

export const AddAppointment = async (req, res) => {
  try {
    const { patientId, donorId, date } = req.body;

    // Create new appointment
    if (!patientId || !donorId) {
      res.status(201).json({
        status: false,
        message: "No record Added",
      });
    }
    const newAppointment = new Appointment({
      patientId: patientId,
      donorId: donorId,
      date,
    });
    const appointment = await newAppointment.save();

    // Update Patient's appointments
    await Patient.findByIdAndUpdate(patientId, {
      $push: { appointments: appointment._id },
    });

    // Update donor's received appointments
    await Doner.findByIdAndUpdate(donorId, {
      $push: { receivedAppointments: appointment._id },
    });

    res.status(200).json({
      status: true,
      message: "Appointment create successfully",
      data: appointment,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

export const getAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find()
      .select("-password")
      .populate("patientId")
      .populate("donorId");

    res.status(200).json(appointments);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
